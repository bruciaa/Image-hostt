// Not used directly; axios instance is in App.tsx. Keeping placeholder if needed later.
export {}
