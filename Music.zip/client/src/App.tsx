import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import axios from 'axios'
import { useEffect, useState } from 'react'
import Navbar from './components/Navbar'

export const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  withCredentials: true
})

export default function App() {
  const [me, setMe] = useState<any>(null)
  const navigate = useNavigate()

  useEffect(() => {
    API.get('/auth/me').then(r => setMe(r.data.user)).catch(() => setMe(null))
  }, [])

  return (
    <div className='text-white'>
      <Navbar me={me} onLogout={async () => {
        await API.post('/auth/logout')
        setMe(null)
        navigate('/login')
      }}/>
      <main className='max-w-5xl mx-auto px-4 py-6'>
        <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{duration:0.4}}>
          <Outlet />
        </motion.div>
      </main>
    </div>
  )
}
