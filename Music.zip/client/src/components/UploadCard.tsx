import { useState } from 'react'
import { motion } from 'framer-motion'
import { API } from '../App'

export default function UploadCard({ onUploaded }: { onUploaded: () => void }) {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [url, setUrl] = useState<string | null>(null)
  const [err, setErr] = useState<string | null>(null)

  async function handleUpload() {
    if (!file) return
    setUploading(true)
    setErr(null)
    try {
      const form = new FormData()
      form.append('image', file)
      const resp = await API.post('/images/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } })
      setUrl(resp.data.url)
      onUploaded()
    } catch (e:any) {
      setErr(e?.response?.data?.error || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }

  return (
    <motion.div layout className='card p-6'>
      <h2 className='text-xl font-semibold mb-2'>Upload an image</h2>
      <p className='text-sm opacity-80 mb-3'>Images will be stored in your Discord channel and you’ll get a direct CDN link.</p>
      <input type='file' accept='image/*' onChange={e=>setFile(e.target.files?.[0] || null)} className='mb-3' />
      <div className='flex gap-2'>
        <button disabled={!file || uploading} onClick={handleUpload} className='px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50'>
          {uploading ? 'Uploading…' : 'Upload'}
        </button>
        {url && <a href={url} target='_blank' className='px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20'>Open Link</a>}
      </div>
      {err && <div className='text-red-300 text-sm mt-2'>{err}</div>}
    </motion.div>
  )
}
