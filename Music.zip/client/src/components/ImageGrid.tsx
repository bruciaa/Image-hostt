import { motion } from 'framer-motion'

export default function ImageGrid({ images }: { images: any[] }) {
  return (
    <motion.div layout className='grid sm:grid-cols-2 md:grid-cols-3 gap-4'>
      {images.map((img, i) => (
        <motion.a
          href={img.url}
          target='_blank'
          className='card overflow-hidden block group'
          key={img._id || i}
          initial={{opacity:0, y:10}}
          animate={{opacity:1, y:0}}
          transition={{duration:0.2, delay: i*0.03}}
        >
          <img src={img.url} className='w-full h-40 object-cover group-hover:scale-[1.02] transition' />
          <div className='p-3 text-sm opacity-80 flex items-center justify-between'>
            <span className='truncate'>{img.filename}</span>
            <span>{(img.size/1024).toFixed(1)} KB</span>
          </div>
        </motion.a>
      ))}
    </motion.div>
  )
}
