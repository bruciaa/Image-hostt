import { Link } from 'react-router-dom'

export default function Navbar({ me, onLogout }: { me:any, onLogout: () => void }) {
  return (
    <header className='sticky top-0 z-10 bg-gradient-to-r from-brand-900/80 to-brand-800/80 backdrop-blur border-b border-white/10'>
      <div className='max-w-5xl mx-auto px-4 py-3 flex items-center justify-between'>
        <Link to='/' className='font-bold text-xl'>📸 Discord Host</Link>
        <nav className='space-x-4'>
          {me ? (
            <>
              <span className='opacity-90'>Hi, {me.username}</span>
              <Link to='/dashboard' className='px-3 py-1 rounded-lg bg-brand-600 hover:bg-brand-500 transition'>Dashboard</Link>
              <button onClick={onLogout} className='px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 transition'>Logout</button>
            </>
          ) : (
            <>
              <Link to='/login' className='px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 transition'>Login</Link>
              <Link to='/register' className='px-3 py-1 rounded-lg bg-brand-600 hover:bg-brand-500 transition'>Sign up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
