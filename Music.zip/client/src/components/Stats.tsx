export default function Stats({ count, totalBytes }: { count: number, totalBytes: number }) {
  const mb = totalBytes / (1024*1024)
  return (
    <div className='card p-6'>
      <h2 className='text-xl font-semibold mb-2'>Your stats</h2>
      <div className='grid grid-cols-2 gap-3'>
        <div className='p-4 rounded-lg bg-white/5 border border-white/10'>
          <div className='text-3xl font-bold'>{count}</div>
          <div className='opacity-80 text-sm'>Images posted</div>
        </div>
        <div className='p-4 rounded-lg bg-white/5 border border-white/10'>
          <div className='text-3xl font-bold'>{mb.toFixed(2)} MB</div>
          <div className='opacity-80 text-sm'>Storage used</div>
        </div>
      </div>
    </div>
  )
}
