import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { API } from '../App'
import UploadCard from '../components/UploadCard'
import ImageGrid from '../components/ImageGrid'
import Stats from '../components/Stats'

export default function Dashboard() {
  const [images, setImages] = useState<any[]>([])
  const [stats, setStats] = useState<{count:number,totalBytes:number}>({count:0,totalBytes:0})

  async function refresh() {
    const [im, st] = await Promise.all([
      API.get('/images/my'),
      API.get('/stats/my'),
    ])
    setImages(im.data.images || [])
    setStats(st.data)
  }

  useEffect(() => {
    refresh().catch(console.error)
  }, [])

  return (
    <div className='space-y-6'>
      <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} transition={{duration:0.3}} className='grid md:grid-cols-2 gap-4'>
        <UploadCard onUploaded={refresh} />
        <Stats count={stats.count} totalBytes={stats.totalBytes} />
      </motion.div>
      <ImageGrid images={images} />
    </div>
  )
}
