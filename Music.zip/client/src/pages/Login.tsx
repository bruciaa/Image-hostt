import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { API } from '../App'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  async function handle(e:any) {
    e.preventDefault()
    setError(null)
    try {
      await API.post('/auth/login', { email, password })
      navigate('/dashboard')
    } catch (e:any) {
      setError(e?.response?.data?.error || 'Login failed')
    }
  }

  return (
    <motion.div initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className='grid place-items-center mt-10'>
      <form onSubmit={handle} className='card p-6 w-full max-w-md'>
        <h1 className='text-2xl font-semibold mb-4'>Welcome back</h1>
        <label className='block text-sm mb-1'>Email</label>
        <input value={email} onChange={e=>setEmail(e.target.value)} type='email' className='w-full mb-3 px-3 py-2 rounded bg-white/10 outline-none border border-white/10 focus:border-brand-500' />
        <label className='block text-sm mb-1'>Password</label>
        <input value={password} onChange={e=>setPassword(e.target.value)} type='password' className='w-full mb-3 px-3 py-2 rounded bg-white/10 outline-none border border-white/10 focus:border-brand-500' />
        {error && <div className='text-red-300 text-sm mb-3'>{error}</div>}
        <button className='w-full mt-2 px-4 py-2 rounded-lg bg-brand-600 hover:bg-brand-500 shadow-glow transition'>Login</button>
        <p className='text-sm opacity-80 mt-3'>No account? <Link to='/register' className='underline'>Create one</Link></p>
      </form>
    </motion.div>
  )
}
