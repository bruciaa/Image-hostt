import { Router } from 'express';
import multer from 'multer';
import { requireAuth } from '../middleware/auth.js';
import { uploadToDiscord } from '../utils/discord.js';
import { Image } from '../models/Image.js';

const router = Router();

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } }); // 25MB

router.get('/my', requireAuth, async (req, res) => {
  const user = (req as any).user;
  const images = await Image.find({ userId: user.id }).sort({ createdAt: -1 });
  res.json({ images });
});

router.post('/upload', requireAuth, upload.single('image'), async (req, res) => {
  const user = (req as any).user;
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  try {
    const { url } = await uploadToDiscord(req.file.buffer, req.file.originalname, req.file.mimetype);
    const doc = await Image.create({
      userId: user.id,
      url,
      filename: req.file.originalname,
      size: req.file.size,
    });
    res.json({ id: doc._id, url: doc.url, size: doc.size, filename: doc.filename, createdAt: doc.createdAt });
  } catch (e: any) {
    console.error('Discord upload failed', e?.response?.data || e);
    res.status(500).json({ error: 'Upload failed' });
  }
});

export default router;
