import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { Image } from '../models/Image.js';

const router = Router();

router.get('/my', requireAuth, async (req, res) => {
  const user = (req as any).user;
  const agg = await Image.aggregate([
    { $match: { userId: (user.id as any) } },
    { $group: { _id: '$userId', totalBytes: { $sum: '$size' }, count: { $count: {} } } },
  ]);

  const { totalBytes = 0, count = 0 } = agg[0] || {};
  res.json({ count, totalBytes });
});

export default router;
