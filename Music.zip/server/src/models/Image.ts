import mongoose, { Schema, InferSchemaType } from 'mongoose';

const ImageSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  url: { type: String, required: true },
  filename: { type: String, required: true },
  size: { type: Number, required: true }, // bytes
  createdAt: { type: Date, default: Date.now }
});

export type ImageDoc = InferSchemaType<typeof ImageSchema> & { _id: mongoose.Types.ObjectId };

export const Image = mongoose.model('Image', ImageSchema);
