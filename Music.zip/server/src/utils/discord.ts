import axios from 'axios';
import FormData from 'form-data';
import { cfg } from '../config.js';

export async function uploadToDiscord(buffer: Buffer, filename: string, mimetype: string): Promise<{ url: string }> {
  if (!cfg.discordToken || !cfg.discordChannelId) {
    throw new Error('Discord token or channel id not configured');
  }

  const form = new FormData();
  form.append('files[0]', buffer, {
    filename,
    contentType: mimetype,
  });
  // Optional: include payload_json to name attachments (recommended by Discord v10+)
  form.append('payload_json', JSON.stringify({
    attachments: [{ id: 0, filename }],
    content: `Uploaded: ${filename}`,
  }));

  const resp = await axios.post(`https://discord.com/api/v10/channels/${cfg.discordChannelId}/messages`, form, {
    headers: {
      Authorization: `Bot ${cfg.discordToken}`,
      ...form.getHeaders(),
    },
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
  });

  const attachment = resp.data?.attachments?.[0];
  if (!attachment?.url) throw new Error('No attachment URL returned by Discord');
  return { url: attachment.url as string };
}
