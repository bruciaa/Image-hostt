export const cfg = {
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  discordToken: process.env.DISCORD_BOT_TOKEN || '',
  discordChannelId: process.env.DISCORD_CHANNEL_ID || '',
};
