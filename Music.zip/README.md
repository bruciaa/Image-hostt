# Discord Image Host — Full-Stack TS App

A full‑fledged image hosting web app with:
- **Discord storage**: Images are uploaded directly to a Discord channel via your bot token.
- **MongoDB auth**: Register/Login with hashed passwords, JWT stored as httpOnly cookie.
- **Stats**: “You posted X images” and “Storage used Y” per user.
- **Purple animated UI** (Tailwind + Framer Motion) with upload, gallery, and stats.

## Tech
- Backend: Node + Express + TypeScript, MongoDB (Mongoose), Multer (memory), JWT (httpOnly cookie), Axios
- Frontend: React + TypeScript + Vite, TailwindCSS, Framer Motion, React Router, Axios

## Setup

### 1) Prereqs
- Node 18+
- MongoDB connection string (Atlas or local)
- Discord bot with permissions to post in your chosen channel
  - Add the bot to your server, grant it **Send Messages** and **Attach Files** in the target channel.

### 2) Configure the backend
Create a `.env` file inside `server/` based on `.env.example`:
```
MONGODB_URI=mongodb+srv://<user>:<pass>@<cluster>/<db>?retryWrites=true&w=majority
JWT_SECRET=super-secret-change-me
DISCORD_BOT_TOKEN=your-bot-token-here
DISCORD_CHANNEL_ID=target-channel-id-here
CLIENT_ORIGIN=http://localhost:5173
PORT=5000
```

### 3) Install & run (dev)
```bash
# in one terminal
cd server
npm install
npm run dev

# in another terminal
cd client
npm install
npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:5000

### 4) Build for production
```bash
# server
cd server
npm run build
npm start

# client (serves static build via Vite preview; in production, host behind any static server)
cd client
npm run build
npm run preview
```

## Notes
- Uploaded images are **not** stored on your server; they’re proxied to Discord. We persist only metadata (URL, size, filename, owner, timestamp) in MongoDB.
- “Storage used” equals the sum of your uploaded image file sizes in bytes as recorded at upload time.
- JWT is set as an **httpOnly** cookie; the frontend makes API calls with `withCredentials: true`.
- Ensure your Discord bot can post to the configured channel ID.
